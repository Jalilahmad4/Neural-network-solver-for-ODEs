function y = trialy(x, a, A, p)
   y = A + (x - a).*Net(x, p);