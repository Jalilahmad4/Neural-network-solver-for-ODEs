function y = sigma(z)
  y = 1./(1 + exp(-z));