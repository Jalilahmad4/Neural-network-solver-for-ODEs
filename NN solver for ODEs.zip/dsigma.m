function y = dsigma(z)
  S = sigma(z);
  y = S.*(1 - S);