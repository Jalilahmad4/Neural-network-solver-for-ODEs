function z = f(x,y)
   z = exp(-x) - y;